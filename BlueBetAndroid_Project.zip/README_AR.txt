BlueBet Demo - مشروع Android
هذه نسخة تجريبية برصيد افتراضي فقط.

لإخراج APK:
1. افتح المشروع في Android Studio.
2. انتظر انتهاء Gradle Sync.
3. من القائمة Build اختر Generate App Bundles or APKs ثم Build APK(s).
4. ستجد ملف APK داخل app/build/outputs/apk/debug/.

لا توجد عمليات إيداع أو سحب مالية حقيقية.
